/**
 * ui.js — User interface logic for the robotic arm visualizer.
 *
 * Phase 1 — Configuration:
 *   User sets number of joints, and for each joint: type, base length, min, max.
 *   "Launch Visualizer" transitions to phase 2.
 *
 * Phase 2 — Control:
 *   One slider per joint drives joint.value in real time.
 *   Canvas redraws on every slider input event.
 *   "Reset All" and "← Reconfigure" buttons available.
 *
 * Depends on: arm.js (Arm), renderer.js (Renderer), trajectory.js (TrajectoryPlayer).
 */
(function (global) {
  'use strict';

  // ── State ─────────────────────────────────────────────────────────────────

  let joints  = [];
  let canvas  = null;
  let ctx     = null;
  let player  = null; // TrajectoryPlayer instance (stub)

  // ── Utility ───────────────────────────────────────────────────────────────

  function fmt(value, type) {
    const n = parseFloat(value).toFixed(1);
    return type === 'rotary' ? n + '°' : n + ' px';
  }

  function baseCoords() {
    return { x: canvas.width / 2, y: canvas.height - 40 };
  }

  function resizeCanvas() {
    const rect = canvas.getBoundingClientRect();
    canvas.width  = rect.width;
    canvas.height = rect.height;
  }

  // ── Render loop ───────────────────────────────────────────────────────────

  function redraw() {
    resizeCanvas();
    const { x, y } = baseCoords();
    const points = Arm.computeFK(joints, x, y);
    Renderer.render(ctx, points, joints);
    updateEndpointDisplay(points);
  }

  function updateEndpointDisplay(points) {
    const ep    = points[points.length - 1];
    const base  = points[0];
    const dispX = (ep.x - base.x).toFixed(1);
    const dispY = (-(ep.y - base.y)).toFixed(1); // flip Y so up = positive
    const el = document.getElementById('endpoint-display');
    if (el) el.textContent = `End-effector: (${dispX} px, ${dispY} px)`;
  }

  // ── Phase 1: Config ───────────────────────────────────────────────────────

  function buildJointRows(count) {
    const container = document.getElementById('joint-rows');
    container.innerHTML = '';

    for (let i = 0; i < count; i++) {
      const row = document.createElement('div');
      row.className = 'joint-row';
      row.innerHTML = `
        <div class="joint-row-header">
          <span class="joint-index">Joint ${i + 1}</span>
          <select class="joint-type-select" data-idx="${i}">
            <option value="rotary">Rotary</option>
            <option value="prismatic">Prismatic</option>
          </select>
        </div>
        <div class="joint-row-fields">
          <label>
            <span>Length</span>
            <div class="input-unit-wrap">
              <input type="number" class="field-length" value="100" min="10" max="500" step="1">
              <span class="unit-badge">px</span>
            </div>
          </label>
          <label>
            <span>Min</span>
            <div class="input-unit-wrap">
              <input type="number" class="field-min" value="-90" step="1">
              <span class="unit-badge unit-badge-type">°</span>
            </div>
          </label>
          <label>
            <span>Max</span>
            <div class="input-unit-wrap">
              <input type="number" class="field-max" value="90" step="1">
              <span class="unit-badge unit-badge-type">°</span>
            </div>
          </label>
        </div>`;
      container.appendChild(row);

      // Keep unit badges in sync with type selector
      const sel    = row.querySelector('.joint-type-select');
      const badges = row.querySelectorAll('.unit-badge-type');
      sel.addEventListener('change', () => {
        const u = sel.value === 'rotary' ? '°' : 'px';
        badges.forEach(b => b.textContent = u);
        const minEl = row.querySelector('.field-min');
        const maxEl = row.querySelector('.field-max');
        if (sel.value === 'rotary') {
          minEl.value = -90; maxEl.value = 90;
        } else {
          minEl.value = -50; maxEl.value = 200;
        }
      });
    }
  }

  function readConfig() {
    const rows = document.querySelectorAll('.joint-row');
    joints = [];
    rows.forEach((row, i) => {
      const type       = row.querySelector('.joint-type-select').value;
      const baseLength = parseFloat(row.querySelector('.field-length').value) || 100;
      const min        = parseFloat(row.querySelector('.field-min').value);
      const max        = parseFloat(row.querySelector('.field-max').value);
      joints.push(Arm.createJoint({ id: i, type, baseLength, min, max }));
    });
  }

  function initConfig() {
    const countInput = document.getElementById('joint-count');
    countInput.addEventListener('input', () => {
      const n = Math.min(8, Math.max(1, parseInt(countInput.value) || 1));
      buildJointRows(n);
    });
    buildJointRows(parseInt(countInput.value) || 3);

    document.getElementById('btn-launch').addEventListener('click', () => {
      readConfig();
      showVisualizer();
    });
  }

  // ── Phase 2: Control ──────────────────────────────────────────────────────

  function buildSliders() {
    const container = document.getElementById('slider-panel');
    container.innerHTML = '';

    joints.forEach((joint, i) => {
      const typeLabel = joint.type === 'rotary' ? 'Rotary' : 'Prismatic';
      const unit      = joint.type === 'rotary' ? '°' : ' px';
      const typeClass = joint.type === 'rotary' ? 'tag-rotary' : 'tag-prismatic';

      const card = document.createElement('div');
      card.className = 'slider-card';
      card.innerHTML = `
        <div class="slider-header">
          <span class="slider-label">Joint ${i + 1}</span>
          <span class="joint-tag ${typeClass}">${typeLabel}</span>
        </div>
        <div class="slider-row">
          <span class="slider-bound">${joint.min}${unit}</span>
          <input
            type="range"
            class="joint-slider"
            min="${joint.min}"
            max="${joint.max}"
            value="0"
            step="${joint.type === 'rotary' ? 0.5 : 1}"
            data-idx="${i}">
          <span class="slider-bound">${joint.max}${unit}</span>
        </div>
        <div class="slider-readout">
          <span class="readout-value" id="readout-${i}">0${unit}</span>
        </div>`;
      container.appendChild(card);

      const slider = card.querySelector('.joint-slider');
      slider.addEventListener('input', () => {
        joint.value = parseFloat(slider.value);
        document.getElementById(`readout-${i}`).textContent = fmt(slider.value, joint.type);
        redraw();
      });
    });
  }

  // ── Phase transitions ─────────────────────────────────────────────────────

  function showVisualizer() {
    document.getElementById('phase-config').classList.add('hidden');
    document.getElementById('phase-control').classList.remove('hidden');

    buildSliders();

    // Initialise TrajectoryPlayer stub (future use)
    player = new TrajectoryPlayer(joints, redraw);

    // First draw
    requestAnimationFrame(redraw);
  }

  function showConfig() {
    document.getElementById('phase-control').classList.add('hidden');
    document.getElementById('phase-config').classList.remove('hidden');
  }

  // ── Bootstrap ─────────────────────────────────────────────────────────────

  function init() {
    canvas = document.getElementById('arm-canvas');
    ctx    = canvas.getContext('2d');

    window.addEventListener('resize', () => { if (!document.getElementById('phase-control').classList.contains('hidden')) redraw(); });

    initConfig();

    document.getElementById('btn-reset').addEventListener('click', () => {
      Arm.resetJoints(joints);
      document.querySelectorAll('.joint-slider').forEach(s => { s.value = 0; });
      joints.forEach((j, i) => {
        const el = document.getElementById(`readout-${i}`);
        if (el) el.textContent = fmt(0, j.type);
      });
      redraw();
    });

    document.getElementById('btn-reconfig').addEventListener('click', showConfig);
  }

  document.addEventListener('DOMContentLoaded', init);

})(window);
