/**
 * trajectory.js — TrajectoryPlayer stub.
 *
 * This module defines the public API for trajectory playback so that future
 * implementation does not require changes to arm.js, renderer.js, or ui.js.
 * In v1, none of these methods perform any action; they exist solely to
 * establish the interface contract.
 *
 * Trajectory data format (for future reference):
 * [
 *   {
 *     jointId  : Number,
 *     keyframes: [ { t: Number (seconds), value: Number }, ... ]
 *   },
 *   ...
 * ]
 */
(function (global) {
  'use strict';

  class TrajectoryPlayer {
    /**
     * @param {object[]} joints  Reference to the arm's joint array.
     * @param {Function} onUpdate  Callback invoked with updated joints during playback.
     */
    constructor(joints, onUpdate) {
      this._joints    = joints;
      this._onUpdate  = onUpdate || function () {};
      this._data      = [];
      this._playing   = false;
      this._startTime = null;
      this._rafId     = null;
    }

    /**
     * Loads trajectory data into the player.
     * Validates that each entry references a valid jointId.
     * @param {object[]} trajectories
     */
    load(trajectories) {
      // TODO (v2): validate keyframe data; interpolate between keyframes during play
      this._data = trajectories || [];
      console.info('[TrajectoryPlayer] Loaded', this._data.length, 'trajectory track(s). (playback not yet implemented)');
    }

    /** Begins trajectory playback from the current position. */
    play() {
      // TODO (v2): start requestAnimationFrame loop; interpolate joint values
      console.info('[TrajectoryPlayer] play() — not yet implemented');
    }

    /** Pauses playback without resetting position. */
    pause() {
      // TODO (v2): cancel rAF loop; preserve elapsed time
      console.info('[TrajectoryPlayer] pause() — not yet implemented');
    }

    /** Stops playback and resets to t = 0. */
    reset() {
      // TODO (v2): cancel rAF loop; reset elapsed time; restore joint values to t=0
      console.info('[TrajectoryPlayer] reset() — not yet implemented');
    }

    /**
     * Seeks to a specific time and updates joint values accordingly.
     * @param {number} t  Time in seconds.
     */
    seek(t) {
      // TODO (v2): interpolate joint values at time t; invoke onUpdate callback
      console.info('[TrajectoryPlayer] seek(' + t + ') — not yet implemented');
    }

    /** Returns whether the player is currently running. */
    get isPlaying() { return this._playing; }
  }

  global.TrajectoryPlayer = TrajectoryPlayer;
})(window);
